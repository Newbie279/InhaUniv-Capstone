import os
# Numerical libs
import numpy as np
import torch
import torch.nn as nn
from scipy.io import loadmat
# Our libs
from src.semanticsegmentation.dataset import TestDataset
from src.semanticsegmentation.models import ModelBuilder, SegmentationModule
from src.semanticsegmentation.utils import colorEncode
from torchvision import transforms
from src.semanticsegmentation.lib.nn import async_copy_to
from src.semanticsegmentation.lib.utils import as_numpy
from src.semanticsegmentation import opt
import cv2

#only used in this Model
colors = loadmat('./src/semanticsegmentation/data/color150.mat')['colors']


class SegmentationModel(object):

    def __init__(self, encoder_model='mobilenetv2dilated', decoder_model='c1_deepsup', fc_dim=320, num_class=150):

        self.encoder_model = encoder_model
        self.decoder_model = decoder_model
        self.fc_dim = fc_dim
        self.num_class = num_class
        self.gpu = 0
        self.imgSize = [300, 400, 500, 600]
        # absolute paths of model weights
        self.weights_encoder = os.path.join("./src/semanticsegmentation/",
                                            'encoder_epoch_50.pth')
        self.weights_decoder = os.path.join("./src/semanticsegmentation/",
                                            'decoder_epoch_50.pth')

        assert os.path.exists(self.weights_encoder) and \
               os.path.exists(self.weights_decoder), 'checkpoint does not exitst!'

        # Network Builders
        builder = ModelBuilder()
        net_encoder = builder.build_encoder(
            arch=self.encoder_model,
            fc_dim=self.fc_dim,
            weights=self.weights_encoder)
        net_decoder = builder.build_decoder(
            arch=self.decoder_model,
            fc_dim=2048,
            num_class=self.num_class,
            weights=self.weights_decoder,
            use_softmax=True)

        crit = nn.NLLLoss(ignore_index=-1)

        self.segmentation_module = SegmentationModule(net_encoder, net_decoder, crit)
        self.segmentation_module = self.segmentation_module.cuda()

        # Main loop
        print('Inference done!')

    def make_multiscale_image(self, input_image):
        # below code is multiscaling input image

        # Round x to the nearest multiple of p and x' >= x
        def round2nearest_multiple(x, p):
            return ((x - 1) // p + 1) * p

        # mean and std
        img_transform = transforms.Compose([
            transforms.Normalize(mean=[102.9801, 115.9465, 122.7717], std=[1., 1., 1.])
            ])

        ori_height, ori_width, _ = input_image.shape

        img_resized_list = []

        for this_short_size in opt.imgSize:
            # calculate target height and width
            scale = min(this_short_size / float(min(ori_height, ori_width)),
                        opt.imgMaxSize / float(max(ori_height, ori_width)))
            target_height, target_width = int(ori_height * scale), int(ori_width * scale)

            # to avoid rounding in network
            target_height = round2nearest_multiple(target_height, opt.padding_constant)
            target_width = round2nearest_multiple(target_width, opt.padding_constant)

            # resize
            img_resized = cv2.resize(input_image.copy(), (target_width, target_height))

            # image to float
            img_resized = img_resized.astype(np.float32)
            img_resized = img_resized.transpose((2, 0, 1))
            img_resized = img_transform(torch.from_numpy(img_resized))

            img_resized = torch.unsqueeze(img_resized, 0)
            img_resized_list.append(img_resized)

        output = dict()
        output['img_ori'] = input_image.copy()
        output['img_data'] = [x.contiguous() for x in img_resized_list]

        return output

    #cv2 mat type image
    def segment(self, input_image, save_img_path, save_result=False):

        self.segmentation_module.eval()

        segSize = (input_image.shape[0], input_image.shape[1])
        input_image = input_image[:, :, ::-1]  # BGR to RGB!!!

        scores = torch.zeros(1, self.num_class, segSize[0], segSize[1])
        scores = async_copy_to(scores, self.gpu)

        feed_dict={}

        with torch.no_grad():
            img_resized_list = self.make_multiscale_image(input_image)

            for img in img_resized_list['img_data']:
                feed_dict['img_data'] = img
                feed_dict = async_copy_to(feed_dict, self.gpu)

             # forward pass
                pred_tmp = self.segmentation_module(feed_dict, segSize=segSize)
                scores = scores + pred_tmp / len(opt.imgSize)

            _, pred = torch.max(scores, dim=1)
            pred = as_numpy(pred.squeeze(0).cpu())

            return self.save_img(input_image, pred, save_img_path, save_result)


    def save_img(self, input_image, pred, save_img_path, save_result=False):
        # prediction

        #human label index=12
        pred[pred != 12] = -1
        pred[pred == 12] = 0
        pred_color = colorEncode(pred, colors)

        kernel = np.ones((7, 7), np.uint8)
        pred_color = cv2.morphologyEx(pred_color,cv2.MORPH_CLOSE, kernel=kernel)

        # aggregate images and save1
        im_vis = pred_color.astype(np.uint8)

        if save_result:
            cv2.imwrite(save_img_path.replace('.jpg', '.png'), im_vis)

        return im_vis
