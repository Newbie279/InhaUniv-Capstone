imgSize = [300, 400, 500, 600]
imgMaxSize = 1000
padding_constant = 8
segm_downsampling_rate = 8
num_val = -1
batch_size = 1
