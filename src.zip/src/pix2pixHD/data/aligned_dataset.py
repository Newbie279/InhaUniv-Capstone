### Copyright (C) 2017 NVIDIA Corporation. All rights reserved. 
### Licensed under the CC BY-NC-SA 4.0 license (https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode).
import os.path
from data.base_dataset import BaseDataset, get_params, get_transform, normalize
from data.image_folder import make_dataset
from PIL import Image

debug=False

class AlignedDataset(BaseDataset):
    def initialize(self, opt):
        self.opt = opt
        self.root = opt.dataroot    
        self.isTrain2 = opt.isTrain

        ### input A (label maps)
        dir_A = '_A' if self.opt.label_nc == 0 else '_label'

        self.dir_A_List = []

        if not opt.isTrain:
            if opt.people_num == 1:
                self.dir_A_List.append(os.path.join(opt.dataroot, opt.phase + dir_A))
            else:

                for idx in range(opt.people_num):
                    self.dir_A_List.append(os.path.join(opt.dataroot, opt.phase + dir_A + "/p" + str(idx)))

        else:
            self.dir_A_List.append(os.path.join(opt.dataroot, opt.phase + dir_A))


        if debug:
            print("Label Map=====")
            print(self.dir_A)

        self.A_paths_List = []

        for dir in self.dir_A_List:
            self.A_paths_List.append(sorted(make_dataset(dir)))

        ### input B (real images)
        if opt.isTrain:
            dir_B = '_B' if self.opt.label_nc == 0 else '_img'
            self.dir_B = os.path.join(opt.dataroot, opt.phase + dir_B)

            if debug:
                print("Real Image=====")
                print(self.dir_B)
            self.B_paths = sorted(make_dataset(self.dir_B))
        else:
            dir_B = '_B' if self.opt.label_nc == 0 else 'images'
            self.dir_B = os.path.join(opt.dataroot, dir_B)

            if debug:
                print("Real Image=====")
                print(self.dir_B)
            self.B_paths = sorted(make_dataset(self.dir_B))

        ### instance maps
        if not opt.no_instance:
            self.dir_inst = os.path.join(opt.dataroot, opt.phase + '_inst')
            self.inst_paths = sorted(make_dataset(self.dir_inst))

        if opt.use_semantic_map:
            self.dir_semantic = os.path.join(opt.dataroot, opt.phase + '_semantic')
            self.semantic_paths = sorted(make_dataset(self.dir_semantic))

        ### load precomputed instance-wise encoded features
        if opt.load_features:                              
            self.dir_feat = os.path.join(opt.dataroot, opt.phase + '_feat')
            print('----------- loading features from %s ----------' % self.dir_feat)
            self.feat_paths = sorted(make_dataset(self.dir_feat))

        self.dataset_size=0
        if opt.isTrain:
            self.dataset_size = len(self.A_paths_List[0])
        else:
            for list in self.A_paths_List:
                self.dataset_size += len(list)
      
    def __getitem__(self, index):        
        ### input A (label maps)


        self.A_tensor_List = []
        A_path_List = []
        for list in self.A_paths_List:

            self.A_path = list[index]
            A_path_List.append(self.A_path)
            A = Image.open(self.A_path)
            params = get_params(self.opt, A.size)
            if self.opt.label_nc == 0:
                transform_A = get_transform(self.opt, params)
                self.A_tensor_List.append(transform_A(A.convert('RGB')))
            else:
                transform_A = get_transform(self.opt, params, method=Image.NEAREST, normalize=False)
                self.A_tensor_List.append(transform_A(A) * 255.0)

        B_tensor = inst_tensor = feat_tensor = semantic_tensor = 0
        ### input B (real images)
        if self.opt.isTrain:
            B_path = self.B_paths[index]

            B = Image.open(B_path).convert('RGB')
            transform_B = get_transform(self.opt, params)
            B_tensor = transform_B(B)
        else:
            B_path = self.B_paths[index]

            B = Image.open(B_path).convert('RGB')
            transform_B = get_transform(self.opt, params)
            B_tensor = transform_B(B)

        ### if using instance maps        
        if not self.opt.no_instance:
            inst_path = self.inst_paths[index]
            inst = Image.open(inst_path)
            inst_tensor = transform_A(inst)

            if self.opt.load_features:
                feat_path = self.feat_paths[index]            
                feat = Image.open(feat_path).convert('RGB')
                norm = normalize()
                feat_tensor = norm(transform_A(feat))

        if self.opt.use_semantic_map:
            semantic_path=self.semantic_paths[index]
            semantic = Image.open(semantic_path)
            semantic_tensor = transform_A(semantic)

        if self.opt.isTrain:
            input_dict = {'label': self.A_tensor_List[0], 'inst': inst_tensor, 'image': B_tensor,
                      'feat': feat_tensor, 'path': self.A_path, 'semantic': semantic_tensor}
        else:
            input_dict = {'label': self.A_tensor_List, 'inst': inst_tensor, 'image': B_tensor,
                      'feat': feat_tensor, 'path': A_path_List, 'semantic': semantic_tensor}


        return input_dict

    def __len__(self):

        if self.isTrain2:
            return len(self.A_paths_List[0]) // self.opt.batchSize * self.opt.batchSize
        else:
            return self.dataset_size // self.opt.batchSize * self.opt.batchSize



    def name(self):
        return 'AlignedDataset'